"""payment URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from .views import TransactionsView, TransactionView, TransactionHistoryView, TransactionHistoriesView

urlpatterns = [
    url(r'^$', TransactionsView.as_view, name='transactions'),
    url(r'^([0-9]{0,8})$', TransactionView.as_view, name='transaction'),
    url(r'^([0-9]{0,8})/histories/$', TransactionHistoriesView.as_view, name='transaction_histories'),
    url(r'^([0-9]{0,8})/histories/([0-9]{0,8})/$', TransactionHistoryView.as_view, name='transaction_history'),
]